#!/usr/bin/env python3
"""【ネギさんが実行】Google Drive（drive.file）を本人認証し、/srv/allmind/.env に保存する。
- 秘密値は画面に表示しない。.env は事前にバックアップ（0600）。ALLMIND_DRIVE_* の行だけ置き換える。
- 使い方: ssh -t negineko@192.168.1.205 "python3 /tmp/allmind_drive/drive_setup.py /tmp/client.json"
"""
import base64, datetime, getpass, hashlib, json, os, secrets, sys, urllib.parse, urllib.request
from pathlib import Path

ENV = Path('/srv/allmind/.env')
SCOPE = 'https://www.googleapis.com/auth/drive.file'
REDIRECT = 'http://127.0.0.1:8599/'

def main():
    if len(sys.argv) != 2 or not sys.stdin.isatty():
        sys.exit('使い方: ssh -t ... "python3 drive_setup.py <client_secret.json>"（対話端末で実行）')
    src = Path(sys.argv[1])
    c = json.loads(src.read_text()).get('installed')
    if not c:
        sys.exit('デスクトップアプリ用の OAuth クライアント JSON ではありません')
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()
    state = secrets.token_urlsafe(16)
    url = 'https://accounts.google.com/o/oauth2/v2/auth?' + urllib.parse.urlencode({
        'client_id': c['client_id'], 'redirect_uri': REDIRECT, 'response_type': 'code', 'scope': SCOPE,
        'access_type': 'offline', 'prompt': 'consent', 'code_challenge': challenge, 'code_challenge_method': 'S256', 'state': state})
    print('\n1) 次の URL をブラウザで開き、Google アカウントで許可してください:\n\n' + url + '\n')
    print('2) 許可後、ブラウザは「127.0.0.1 に接続できません」になります（正常）。')
    print('   そのときのアドレスバーの URL（http://127.0.0.1:8599/?state=...&code=...）を丸ごとコピーして貼り付けてください。')
    back = getpass.getpass('   URL を貼り付けて Enter（表示されません）: ').strip()
    q = urllib.parse.parse_qs(urllib.parse.urlsplit(back).query)
    if q.get('state', [''])[0] != state or 'code' not in q:
        sys.exit('URL が一致しません（state 不一致または code なし）。最初からやり直してください')
    data = urllib.parse.urlencode({'client_id': c['client_id'], 'client_secret': c['client_secret'], 'code': q['code'][0],
                                   'code_verifier': verifier, 'redirect_uri': REDIRECT, 'grant_type': 'authorization_code'}).encode()
    try:
        with urllib.request.urlopen(urllib.request.Request('https://oauth2.googleapis.com/token', data=data), timeout=20) as r:
            tok = json.load(r)
    except Exception as exc:
        sys.exit('トークン取得に失敗しました: ' + type(exc).__name__)
    if not tok.get('refresh_token'):
        sys.exit('refresh token が返りませんでした（同意画面で許可されたか確認してください）')
    os.umask(0o077)
    rev = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    old = ENV.read_text() if ENV.exists() else ''
    if ENV.exists():
        bak = ENV.with_name('.env.bak-' + rev); bak.write_text(old); os.chmod(bak, 0o600)
    lines = [l for l in old.splitlines() if not l.startswith('ALLMIND_DRIVE_')]
    lines += [f"ALLMIND_DRIVE_CLIENT_ID={c['client_id']}", f"ALLMIND_DRIVE_CLIENT_SECRET={c['client_secret']}",
              f"ALLMIND_DRIVE_REFRESH_TOKEN={tok['refresh_token']}"]
    tmp = ENV.with_name('.env.tmp'); tmp.write_text('\n'.join(lines) + '\n'); os.chmod(tmp, 0o600); tmp.replace(ENV)
    src.unlink(missing_ok=True)
    with open('/srv/allmind/CHANGELOG.md', 'a') as f:
        f.write(f"- {datetime.datetime.now():%Y-%m-%d %H:%M} drive: 本人認証で drive.file の資格情報を .env(ALLMIND_DRIVE_*) に保存（.env.bak-{rev}）。client JSON は削除\n")
    print('\n保存しました（値は表示しません）。client JSON は削除しました。')

if __name__ == '__main__':
    main()
