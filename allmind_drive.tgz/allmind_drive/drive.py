"""Google Drive（drive.file）連携。オーケストレーターからだけ使う。
- 資格情報は /srv/allmind/.env の ALLMIND_DRIVE_* 3行だけを読む（他の行は読み捨て・保持しない）
- アプリ自身が作ったフォルダ「ALL-MIND_reports」にレポートを置く。既存の Drive ファイルには触れない
- 失敗しても例外を外へ出さず、状態（connected / error）だけ返す。秘密値・応答本文はログに出さない
"""
import json
import time
import urllib.parse
import urllib.error
import urllib.request
from pathlib import Path

ENV = Path('/srv/allmind/.env')
FOLDER = 'ALL-MIND_reports'
API = 'https://www.googleapis.com/drive/v3'
UPLOAD = 'https://www.googleapis.com/upload/drive/v3/files'
TIMEOUT = 15
_cache = {'token': None, 'exp': 0}


def creds():
    try:
        vals = {}
        for line in ENV.read_text(encoding='utf-8').splitlines():
            if line.startswith('ALLMIND_DRIVE_') and '=' in line:
                k, v = line.split('=', 1)
                vals[k] = v.strip()
        need = ('ALLMIND_DRIVE_CLIENT_ID', 'ALLMIND_DRIVE_CLIENT_SECRET', 'ALLMIND_DRIVE_REFRESH_TOKEN')
        return {k: vals[k] for k in need} if all(vals.get(k) for k in need) else None
    except OSError:
        return None


def _req(method, url, data=None, headers=None):
    req = urllib.request.Request(url, data=data, method=method, headers=headers or {})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        body = r.read(1 << 20)
        return json.loads(body) if body else {}


def token(c):
    if _cache['token'] and time.time() < _cache['exp'] - 60:
        return _cache['token']
    data = urllib.parse.urlencode({'client_id': c['ALLMIND_DRIVE_CLIENT_ID'], 'client_secret': c['ALLMIND_DRIVE_CLIENT_SECRET'],
                                   'refresh_token': c['ALLMIND_DRIVE_REFRESH_TOKEN'], 'grant_type': 'refresh_token'}).encode()
    t = _req('POST', 'https://oauth2.googleapis.com/token', data)
    _cache.update(token=t['access_token'], exp=time.time() + int(t.get('expires_in', 3600)))
    return _cache['token']


def _auth(tok):
    return {'Authorization': 'Bearer ' + tok}


def _find(tok, q):
    r = _req('GET', API + '/files?' + urllib.parse.urlencode({'q': q, 'fields': 'files(id,name,modifiedTime)', 'spaces': 'drive', 'pageSize': 10}), headers=_auth(tok))
    return r.get('files') or []


def folder_id(tok, state):
    fid = (state.get('drive') or {}).get('folder_id')
    if fid:
        return fid
    hits = _find(tok, f"name = '{FOLDER}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false")
    if hits:
        return hits[0]['id']
    meta = json.dumps({'name': FOLDER, 'mimeType': 'application/vnd.google-apps.folder'}).encode()
    return _req('POST', API + '/files?fields=id', meta, {**_auth(tok), 'Content-Type': 'application/json'})['id']


def upload_text(tok, fid, name, text):
    esc = name.replace("'", "\\'")
    hits = _find(tok, f"name = '{esc}' and '{fid}' in parents and trashed = false")
    body = text.encode('utf-8')
    if hits:
        _req('PATCH', UPLOAD + '/' + hits[0]['id'] + '?uploadType=media', body, {**_auth(tok), 'Content-Type': 'text/markdown; charset=utf-8'})
        return
    boundary = 'allmind' + str(int(time.time()))
    meta = json.dumps({'name': name, 'parents': [fid], 'mimeType': 'text/markdown'}).encode()
    multipart = (f'--{boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n'.encode() + meta +
                 f'\r\n--{boundary}\r\nContent-Type: text/markdown; charset=UTF-8\r\n\r\n'.encode() + body + f'\r\n--{boundary}--'.encode())
    _req('POST', UPLOAD + '?uploadType=multipart&fields=id', multipart, {**_auth(tok), 'Content-Type': f'multipart/related; boundary={boundary}'})


def sync(state, reports):
    """日次レポート（直近2日分）を送り、容量を取得。state['drive'] を更新して返す。"""
    info = dict(state.get('drive') or {})
    c = creds()
    if not c:
        info.update(connected=None, sync_status='unconfigured', error=None)
        state['drive'] = info
        return info
    try:
        tok = token(c)
        fid = folder_id(tok, state)
        info['folder_id'] = fid
        for f in sorted(Path(reports).glob('*.md'))[-2:]:
            upload_text(tok, fid, f.name, f.read_text(encoding='utf-8'))
        try:
            q = _req('GET', API + '/about?fields=storageQuota', headers=_auth(tok)).get('storageQuota') or {}
            info.update(storage_used=int(q['usage']) if q.get('usage') else None, storage_total=int(q['limit']) if q.get('limit') else None)
        except Exception:
            info.update(storage_used=None, storage_total=None)
        info.update(connected=True, sync_status='ok', last_sync=time.time(), error=None)
    except urllib.error.HTTPError as exc:
        info.update(connected=False if exc.code in (400, 401, 403) else None, sync_status='error', error=f'http_{exc.code}')
    except Exception as exc:
        info.update(connected=None, sync_status='error', error=type(exc).__name__)
    state['drive'] = info
    return info
