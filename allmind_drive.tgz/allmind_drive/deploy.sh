#!/usr/bin/env bash
# B1: Google Drive（drive.file）連携を配置。資格情報の登録は drive_setup.py（本人実行）で別途。
set -uo pipefail
P="$(cd "$(dirname "$0")" && pwd)"; D=/srv/allmind/dashboard; O=/srv/allmind/orchestrator; REV=$(date +%Y%m%d-%H%M%S)
fail(){ echo "中止: $*"; exit 1; }
chk(){ [ "$(sha256sum "$1" | cut -c1-64)" = "$2" ] || fail "$1 が想定と異なります"; }
chk $O/orchestrator.py d5df0b1ac02b9643bc60daeefd63dd82988e748750c1d713e4e4db7b3c6bad15
chk $D/state_api.py ff00cd441b28e362d5133e8706b64623595d60f6c7fc5c7c4bd62641a876e6a0
chk $D/static/dashboard.html 85da2cebdd8324772f87d821055c380ffe7a3cea5098dd7b40ab706e2adc9c00
exec 9>/mnt/scratch/bridge/logs/orchestrator.lock; flock -n 9 || fail "オーケストレーター実行中（数分後に再実行）"
cp -a $D /srv/allmind/dashboard.before-drive-$REV && docker image tag allmind-dashboard:0.1.0 allmind-dashboard:backup-$REV && cp -a $O/orchestrator.py $O/orchestrator.py.bak-$REV || fail backup
install -m 0644 $P/drive.py $P/files/orchestrator.py $O/ && python3 -m py_compile $O/orchestrator.py $O/drive.py || fail orch
install -m 0644 $P/files/state_api.py $D/ && install -m 0644 $P/files/dashboard.html $D/static/ || fail dash
install -m 0755 $P/drive_setup.py $O/drive_setup.py
flock -u 9
python3 $O/orchestrator.py --status || fail status
cd $D && docker compose -p allmind-dashboard build -q && docker compose -p allmind-dashboard up -d || fail "build/up（戻す: backup dashboard.before-drive-$REV）"
for i in $(seq 1 30); do curl -sf -m 3 http://127.0.0.1:8765/healthz >/dev/null && break; sleep 2; done; sleep 5
curl -s http://127.0.0.1:8765/api/state | python3 -c 'import json,sys;d=json.load(sys.stdin);print("gdrive:",d["nodes"].get("gdrive"))'
docker exec allmind-dashboard python test_adapters.py 2>&1 | tail -n 1
printf -- '- %s drive: Drive 連携モジュール配置（drive.file・オーケストレーターのみ通信・ALL-MIND_reports へ日次レポート送信・容量取得）。資格情報は未登録。backup: dashboard.before-drive-%s / orchestrator.py.bak-%s\n' "$(date '+%Y-%m-%d %H:%M')" "$REV" "$REV" >> /srv/allmind/CHANGELOG.md
echo "完了（資格情報の登録: ssh -t negineko@192.168.1.205 \"python3 /srv/allmind/orchestrator/drive_setup.py /tmp/client.json\"）"
