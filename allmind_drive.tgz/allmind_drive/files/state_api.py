"""Read-only translation of the MCP v1 snapshot into the dashboard's /api/state format.

Only converts values that the existing Monitor already observed. Anything not observed
stays null / empty / UNKNOWN. No new probes, no writes, no external calls.
"""
from datetime import datetime
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
UI = json.loads((ROOT / "state_config.json").read_text(encoding="utf-8"))

NODE_STATUS = {"online": "ONLINE", "reachable": "ONLINE", "unreachable": "OFFLINE", "unknown": "UNKNOWN"}
AI_STATUS = {"available": "AVAILABLE", "online": "AVAILABLE", "unavailable": "STOPPED", "unknown": "UNKNOWN"}
USABLE = {"ok", "partial"}


def epoch(value):
    if not value: return None
    try: return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except ValueError: return None


def gb(value, digits=1):
    return None if value is None else round(value / 1e9, digits)


def tool(snapshot, name):
    """Return data of a tool only when it is usable (not stale / unavailable / unknown)."""
    if not snapshot: return None
    value = snapshot.get("tools", {}).get(name) or {}
    if value.get("status") not in USABLE: return None
    return value.get("data")


def host_report(system, node_self):
    if not system: return {"status": "UNKNOWN"}
    ts = epoch((node_self or {}).get("last_seen")) or epoch((node_self or {}).get("checked_at"))
    net = system.get("network") or {}
    rx, tx = net.get("rx_bytes_per_second"), net.get("tx_bytes_per_second")
    gpu = system.get("gpu") or {}
    ram, disk = system.get("ram") or {}, system.get("disk") or {}
    return {
        "ts": ts, "status": "ONLINE",
        "cpu": system.get("cpu_percent"),
        "ram": ram.get("percent"), "ram_total_gb": gb(ram.get("total_bytes")),
        "disk": disk.get("percent"), "disk_total_gb": gb(disk.get("total_bytes"), 0),
        "net_mbps": None if rx is None or tx is None else round((rx + tx) * 8 / 1e6, 2),
        "temp": None,  # CPU 温度の取得元は未設定（GPU 温度は gpu.temp に分離）
        "uptime_s": system.get("uptime_seconds"),
        "gpu": None if gpu.get("status") != "ok" else {
            "name": gpu.get("name") or "GPU", "util": gpu.get("utilization_percent"),
            "mem_used_gb": gb(gpu.get("memory_used_bytes"), 2), "mem_total_gb": gb(gpu.get("memory_total_bytes"), 1),
            "temp": gpu.get("temperature_c")},
        "services": [{"name": s.get("name"), "status": "RUNNING" if s.get("status") == "online" else "UNKNOWN" if s.get("status") == "unknown" else "ERROR",
                      "models": s.get("models"), "loaded_models": s.get("loaded_models")} for s in system.get("services") or []],
        "metrics": True,
    }


def remote_report(node):
    if not node: return {"status": "UNKNOWN"}
    status = NODE_STATUS.get(node.get("status"), "UNKNOWN")
    if status != "ONLINE": return {"status": status, "reason": node.get("reason")}
    return {"ts": epoch(node.get("last_seen")) or epoch(node.get("checked_at")), "status": "ONLINE",
            "cpu": node.get("cpu_percent"), "ram": None, "disk": None, "net_mbps": None, "temp": None,
            "uptime_s": None, "connection": node.get("connection"), "reason": node.get("reason"),
            "metrics": node.get("cpu_percent") is not None}


def drive_report(drive):
    if drive and drive.get("connected") is False: return {"status": "ERROR", "reason": drive.get("error")}
    if not drive or drive.get("connected") is not True: return {"status": "UNKNOWN"}
    ls = drive.get("last_sync")
    ls = ls if isinstance(ls, (int, float)) else epoch(ls)
    return {"ts": ls, "status": "SYNC" if drive.get("sync_status") in ("ok", "synced") else "ONLINE",
            "used_gb": gb(drive.get("storage_used")), "total_tb": None if drive.get("storage_total") is None else round(drive["storage_total"] / 1e12, 2),
            "last_sync": ls, "metrics": True}


def build_nodes(snapshot):
    system = tool(snapshot, "get_system_status")
    nodes = {n.get("node_id"): n for n in ((tool(snapshot, "get_node_status") or {}).get("nodes") or [])}
    drive = (orch() or {}).get("drive") or tool(snapshot, "get_google_drive_status")  # オーケストレーターの実測を優先
    # ALL-MIND はカードに出さずヘッダーのみ（ユーザー指示）。報告は host_node キーで常に送る
    out = {UI["server"]["host_node"]: host_report(system, nodes.get(UI.get("host_node_source_id", "allmind")))}
    for cfg in UI["config_nodes"]:
        nid, src = cfg["id"], cfg.get("source_id")
        if nid == "gdrive": out[nid] = drive_report(drive)
        elif src: out[nid] = remote_report(nodes.get(src))
        elif cfg.get("unknown"): out[nid] = {"status": "UNKNOWN"}
        # それ以外（Rubicon-03 等）はキー省略 → 画面は「未導入」
    return out


ORCH_PATH = Path(UI.get("orchestrator_state", "/deployment/runtime/orchestrator-state.json"))
ORCH_AI = {"codex": "gpt", "claude": "claude", "grok": "grok", "gemini": "gemini", "local": "local"}
ORCH_AI_STATUS = {"ok": "AVAILABLE", "usage_limit": "LIMIT", "auth_error": "ERROR", "network_error": "ERROR", "timeout": "ERROR", "error": "ERROR"}
ORCH_TASK_STATUS = {"WAITING_LIMIT": "PENDING"}


def orch():
    """オーケストレーターの状態ファイル（読み取りのみ）。無い・壊れている場合は None。"""
    try:
        data = json.loads(ORCH_PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def build_ai(snapshot):
    resources = {r.get("provider"): r for r in ((tool(snapshot, "get_ai_resources") or {}).get("resources") or [])}
    result = []
    for cfg in UI["ai"]:
        r = resources.get(cfg["provider"]) or {}
        task = r.get("current_task") or (r.get("detail") if cfg["id"] == "local" and r else None) or "—"
        result.append({"id": cfg["id"], "name": cfg["name"], "color": cfg["color"], "mark": cfg["mark"], "role": cfg["role"],
                       "status": AI_STATUS.get(r.get("status"), "UNKNOWN"), "task": task, "model": r.get("model"),
                       "usage": r.get("usage"), "quota": r.get("quota")})
    for a in result:
        if a["id"] == "copilot":  # 一般向け Web 版のみ。自動連携の窓口が無いので「手動」と明示
            a.update(status="MANUAL", task="ブラウザで手動利用（自動連携なし）")
    o = orch()
    if o:  # 実際の呼び出し結果（接続試験・自動運用）がある AI だけ上書き。使用量は取得できないので null のまま
        by_id = {a["id"]: a for a in result}
        for provider, info in (o.get("ai") or {}).items():
            a = by_id.get(ORCH_AI.get(provider))
            if a and a["id"] != "local" and info.get("status"):
                a["status"] = ORCH_AI_STATUS.get(info["status"], "UNKNOWN")
                if info.get("task"):
                    a["task"] = str(info["task"])[:60]
    return result


def build_events(snapshot):
    data = tool(snapshot, "get_events") or {}
    events = list(data.get("events") or []) + list(data.get("system_events") or [])
    result = [{"ts": epoch(e.get("timestamp")), "level": e.get("level", "INFO"), "message": e.get("message", ""), "source": e.get("source", "")}
              for e in events if epoch(e.get("timestamp"))]
    o = orch()
    if o:
        result += [{"ts": e.get("ts"), "level": e.get("level", "INFO"), "message": str(e.get("message", ""))[:200], "source": "orchestrator"}
                   for e in (o.get("events") or []) if isinstance(e.get("ts"), (int, float))]
    return sorted(result, key=lambda e: e["ts"], reverse=True)[:60]


def build_tasks_loop():
    o = orch()
    if not o:
        return [], {"current": 0, "progress": 0, "done": 0, "total": 0, "cycle": 0}, "unconfigured"
    tasks = [{"id": t.get("id"), "name": str(t.get("name", ""))[:80], "status": ORCH_TASK_STATUS.get(t.get("status"), t.get("status")),
              "progress": t.get("progress"), "eta": t.get("eta", "—"), "time": t.get("time")} for t in (o.get("tasks") or [])]
    return tasks, o.get("loop") or {"current": 0, "progress": 0, "done": 0, "total": 0, "cycle": 0}, "orchestrator"


def build_state(snapshot):
    tasks, loop, source = build_tasks_loop()
    o = orch() or {}
    agent_events = [e for e in (o.get("agent_events") or []) if isinstance(e, dict)]
    return {
        "server": UI["server"], "health": UI["health"],
        "config_nodes": [{k: v for k, v in n.items() if k not in ("source_id", "unknown")} for n in UI["config_nodes"]],
        "nodes": build_nodes(snapshot), "ai": build_ai(snapshot),
        "projects": o.get("projects") or [], "loop": loop,
        "tasks": tasks, "events": build_events(snapshot),
        "decisions": [e for e in agent_events if e.get("type") in ("decision", "judge")][-30:], "anon": {},
        "digests": o.get("digests") or {}, "settings": o.get("settings"), "agent_seq": max([e.get("seq", 0) for e in agent_events] or [0]),
        "meta": {"observed_at": (snapshot or {}).get("observed_at"), "stale": (snapshot or {}).get("stale", True) if snapshot else True,
                 "sources": {"projects": source, "tasks": source, "loop": source},
                 "chat": "enabled" if CHAT_DIR.exists() else "unconfigured"},
    }


def stream_messages(state, sent_events):
    """SSE messages for one tick. sent_events: set of (ts, message) already delivered（agent は ('agent', seq)）。"""
    msgs = [{"type": "node", "id": nid, "data": rep} for nid, rep in state["nodes"].items()]
    msgs.append({"type": "projects", "data": state["projects"]})
    msgs.append({"type": "digests", "data": state.get("digests") or {}})
    for ev in (orch() or {}).get("agent_events") or []:
        key = ("agent", ev.get("seq"))
        if key not in sent_events:
            sent_events.add(key)
            msgs.append({"type": "agent", "data": ev})
    msgs.append({"type": "ai", "data": state["ai"]})
    msgs.append({"type": "tasks", "data": state["tasks"]})
    msgs.append({"type": "loop", "data": state["loop"]})
    for ev in reversed(state["events"]):
        key = (ev["ts"], ev["message"])
        if key not in sent_events:
            sent_events.add(key)
            msgs.append({"type": "event", "data": ev})
    return msgs


# ------------------------------------------------------------------ チャット（投入・承認コマンド）
import re as _re
import secrets as _secrets
import time as _time

CHAT_DIR = Path(UI.get("chat_inbox", "/chat-inbox"))
TYPE_WORDS = {"調査": "research", "research": "research", "実装": "implement", "implement": "implement",
              "レビュー": "review", "review": "review", "要約": "summary", "summary": "summary"}
HELP = ("使い方: 本文を送るとタスクとして次回サイクルに投入（先頭に「調査:」「実装:」「レビュー:」「要約:」で種別指定、既定は調査）。\n"
        "/list 承認待ち一覧 / /approve ID [メモ] / /reject ID [理由] / /retry ID / /status")


def _write(kind, payload):
    """chat-inbox へ1ファイル書くだけ。上限を超えたら拒否。本文は 16KB まで。"""
    pending = [p for p in CHAT_DIR.iterdir()] if CHAT_DIR.exists() else None
    if pending is None:
        raise OSError("chat_inbox_missing")
    if len(pending) >= int(UI.get("chat_max_pending", 20)):
        return False
    name = f"{int(_time.time())}-{_secrets.token_hex(4)}.{kind}"
    tmp = CHAT_DIR / (name + ".part")
    tmp.write_text(payload, encoding="utf-8")
    tmp.rename(CHAT_DIR / name)
    return True


def handle_chat(body):
    msg = str(body.get("message") or "").strip()[:8000]
    cmd = str(body.get("command") or "").strip()
    project = str(body.get("project") or "").strip()[:60]
    if not msg and cmd:
        msg = cmd
    if not msg or msg in ("/help", "help", "ヘルプ"):
        return {"kind": "help", "reply": HELP}
    o = orch() or {}
    if msg.startswith("/list"):
        rows = [f"・{t['id']}  {t['name']}" for t in (o.get("tasks") or []) if t.get("status") == "HUMAN APPROVAL"]
        return {"kind": "list", "reply": "承認待ち:\n" + ("\n".join(rows) if rows else "（なし）")}
    if msg.startswith("/status"):
        loop = o.get("loop") or {}
        ai = ", ".join(f"{k}:{(v or {}).get('status')}" for k, v in sorted((o.get("ai") or {}).items()))
        nxt = o.get("next_cycle_after")
        when = _time.strftime("%m/%d %H:%M", _time.gmtime(nxt + 9 * 3600)) if isinstance(nxt, (int, float)) else "—"  # JST
        return {"kind": "status", "reply": f"サイクル #{o.get('cycle', 0)} / 承認待ち {sum(1 for t in (o.get('tasks') or []) if t.get('status') == 'HUMAN APPROVAL')} 件 / 次回 {when} 以降\nAI: {ai or '—'}"}
    m = _re.match(r"^/(approve|reject|retry)\s+([0-9A-Za-z._-]{6,80})(?:\s+(.*))?$", msg, _re.S)
    if m:
        ok = _write("cmd", json.dumps({"cmd": m.group(1), "task_id": m.group(2), "note": (m.group(3) or "")[:200]}, ensure_ascii=False))
        label = {"approve": "承認", "reject": "差し戻し", "retry": "やり直し"}[m.group(1)]
        return {"kind": "cmd", "reply": f"{label}を受け付けました（5分以内に反映）: {m.group(2)}" if ok else "受付上限に達しています。少し待ってから再送してください"}
    if msg.startswith("/"):
        return {"kind": "help", "reply": "不明なコマンドです。\n" + HELP}
    ttype = "research"
    head = _re.match(r"^(調査|research|実装|implement|レビュー|review|要約|summary)\s*[:：]\s*", msg, _re.I)
    if head:
        ttype = TYPE_WORDS[head.group(1).lower() if head.group(1).isascii() else head.group(1)]
        msg = msg[head.end():]
    title = (f"[{project}] " if project else "") + msg.splitlines()[0][:60]
    ok = _write("md", f"title: {title}\ntype: {ttype}\n---\n{msg}\n")
    if not ok:
        return {"kind": "task", "reply": "受付上限に達しています。少し待ってから再送してください"}
    return {"kind": "task", "reply": f"タスクを受け付けました（{ttype}）。5分以内にキューへ入り、次回サイクルで処理します。\n件名: {title}"}
