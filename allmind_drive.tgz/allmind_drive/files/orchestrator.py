"""ALL-MIND orchestrator v1 — 5時間ごと（cron 毎時起動＋間隔ガード）に AI を順番に回す。

入力: bridge/inbox/*.md（手置き・n8n・チャット）、config.json の定期ジョブ
処理: 種別ごとの固定パイプライン（振り分けルール）で各 AI を ping.py と同じ隔離条件で実行
出力: bridge/outbox/<id>.md（最終は HUMAN APPROVAL で停止）、ダッシュボード用状態ファイル
禁止: 秘密情報の読取、SB01 への書込、API 従量課金への切替、再試行ループ
"""
import argparse
import datetime
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import urllib.request

HERE = Path(__file__).resolve().parent
CFG = json.loads((HERE / 'config.json').read_text(encoding='utf-8'))
BRIDGE = Path(CFG['bridge'])
INBOX, WORK, OUTBOX, LOGS, CHAT = (BRIDGE / d for d in ('inbox', 'work', 'outbox', 'logs', 'chat-inbox'))
STATE = HERE / 'state.json'
APPROVED, REJECTED, REPORTS = HERE / 'approved', HERE / 'rejected', HERE / 'reports'
DASH = Path(CFG['dashboard_state'])
LOOP_STAGES = ['BUILD', 'RETRIEVE', 'ACT', 'OBSERVE', 'SHIP']

try:
    sys.path.insert(0, str(HERE))
    import drive  # Google Drive（drive.file）。未設定なら何もしない
except ImportError:
    drive = None

spec = importlib.util.spec_from_file_location('ping', CFG['ping_py'])
ping = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ping)


def now():
    return datetime.datetime.now(datetime.timezone.utc)


def iso(t=None):
    return (t or now()).isoformat(timespec='seconds')


def jload(path, default):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return default


def jsave(path, value, mode=0o600):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    os.chmod(tmp, mode)
    tmp.replace(path)


AGENT_ID = {'codex': 'gpt', 'claude': 'claude', 'grok': 'grok', 'gemini': 'gemini', 'local': 'local'}


def agent_event(state, ev):
    """Agent Ops 画面用の実イベント（受付→振り分け→実行→判定）。直近200件だけ保持。"""
    state['agent_seq'] = state.get('agent_seq', 0) + 1
    ev.update(seq=state['agent_seq'], ts=time.time())
    state.setdefault('agent_events', []).append(ev)
    state['agent_events'] = state['agent_events'][-200:]


def task_source(task):
    job = task.get('job') or ''
    if job == 'trade':
        return 'bot'
    if job in ('freesoft', 'note', 'vtuber'):
        return 'market'
    if job:
        return 'n8n'
    return 'chat'


def event(level, message, source='orchestrator'):
    line = {'ts': time.time(), 'level': level, 'message': message[:200], 'source': source}
    with open(LOGS / 'orchestrator.jsonl', 'a', encoding='utf-8') as f:
        f.write(json.dumps(line, ensure_ascii=False) + '\n')
    print(f"[{level}] {message}", flush=True)


# ------------------------------------------------------------------ タスク入力
def parse_task(text, fallback_title):
    """先頭の `key: value` 行（--- まで）をヘッダ、残りを本文とする。"""
    head, body = {}, text
    if '\n---' in text:
        top, body = text.split('\n---', 1)
        for line in top.splitlines():
            if ':' in line:
                k, v = line.split(':', 1)
                head[k.strip().lower()] = v.strip()
    ttype = head.get('type', CFG['default_type'])
    if ttype not in CFG['pipelines']:
        ttype = CFG['default_type']
    return {'title': (head.get('title') or fallback_title)[:80], 'type': ttype, 'job': re.sub(r'[^a-z0-9-]', '', head.get('job', '').lower())[:40] or None,
            'body': body.strip()[:CFG['max_body_chars']]}


def ingest(state):
    count = 0
    for f in sorted(INBOX.glob('*.md'))[:CFG['max_ingest']]:
        if f.is_symlink() or not f.is_file() or f.stat().st_size > CFG['max_body_chars'] * 4:
            f.rename(f.with_suffix('.rejected'))
            event('WARNING', f'inbox: 受付不可のため除外 {f.name}')
            continue
        t = parse_task(f.read_text(encoding='utf-8', errors='replace'), f.stem)
        tid = now().strftime('%Y%m%d-%H%M%S') + '-' + re.sub(r'[^a-z0-9]+', '-', f.stem.lower())[:24].strip('-')
        d, n = WORK / tid, 1
        while d.exists():  # 同一秒・同名の衝突回避
            n += 1
            d = WORK / f'{tid}-{n}'
        tid = d.name
        d.mkdir(mode=0o700)
        (d / 'task.md').write_text(t['body'], encoding='utf-8')
        task = {'id': tid, 'title': t['title'], 'type': t['type'], 'job': t['job'], 'status': 'PENDING', 'stage': 0,
                'stages': CFG['pipelines'][t['type']], 'created': iso(), 'updated': iso(), 'history': []}
        jsave(d / 'task.json', task)
        f.unlink()
        state['tasks'].append(tid)
        event('INFO', f'タスク受付: {t["title"]}（{t["type"]}）')
        count += 1
    return count


def schedule_jobs(state):
    for job in CFG.get('jobs', []):
        if not job.get('enabled'):
            continue
        every = max(1, int(job.get('every_cycles', 1)))
        if state['cycle'] % every != int(job.get('offset', 0)) % every:
            continue
        name = f"job-{job['id']}-{now().strftime('%Y%m%d%H%M')}.md"
        (INBOX / name).write_text(f"title: {job['title']}\ntype: {job['type']}\njob: {job['id']}\n---\n{job['body']}\n", encoding='utf-8')
        event('INFO', f'定期ジョブ投入: {job["title"]}')


# ------------------------------------------------------------------ AI 実行
def previous_job_result(task):
    """同じ定期ジョブの直近の成果（承認済み優先、なければ承認待ち）を返す。積み上げ用。"""
    if not task.get('job'):
        return ''
    for folder in (APPROVED, OUTBOX):
        files = sorted(folder.glob(f"*job-{task['job']}-*.md")) if folder.exists() else []
        files = [f for f in files if task['id'] not in f.name]
        if files:
            return files[-1].read_text(encoding='utf-8')[-CFG['max_prev_chars'] // 2:]
    return ''


def build_prompt(task, stage, body, prev):
    role = CFG['roles'][stage['role']]
    parts = [f"あなたは ALL-MIND オーケストレーションの担当 AI です。役割: {role}",
             "制約: コマンド実行・ファイル操作・外部への送信はしない。秘密情報や個人情報を求めない。回答は日本語の Markdown。",
             f"# タスク: {task['title']}（種別: {task['type']}）", body]
    if task['stage'] == 0:
        last = previous_job_result(task)
        if last:
            parts += ['# 前回までの成果（これを踏まえて次の1段を進める。繰り返しは避ける）', last]
    if prev:
        parts += ['# 前段の出力（これを踏まえて作業する）', prev[-CFG['max_prev_chars']:]]
    if stage['role'] == 'judge':
        parts.append('最後の行に必ず `VERDICT: SHIP`（公開・反映してよい）か `VERDICT: RETRY`（やり直し）のどちらかを書く。')
    return '\n\n'.join(parts)


def cli_argv(provider, prompt, stage):
    if provider == 'codex':
        return ['codex', 'exec', '--skip-git-repo-check', '-s', 'read-only', prompt]
    if provider == 'claude':
        return ['claude', '-p', prompt, '--tools', '', '--permission-mode', 'dontAsk', '--no-session-persistence', '--output-format', 'text']
    if provider == 'grok':
        extra = [] if stage.get('web') else ['--disable-web-search']
        return ['grok', '-p', prompt, '--max-turns', str(CFG['grok_max_turns']), '--permission-mode', 'plan', '--output-format', 'plain', *extra]
    if provider == 'gemini':
        return ['gemini', '-p', prompt, '-m', CFG['gemini_model'], '--approval-mode', 'plan', '--output-format', 'text']
    raise ValueError(provider)


def run_ai(provider, prompt, stage, dry):
    started = time.monotonic()
    if dry:
        return 'ok', f'(dry-run) {provider} {stage["role"]}', 0.0
    if provider == 'local':
        try:
            req = urllib.request.Request(CFG['local_llm']['url'], data=json.dumps(
                {'model': CFG['local_llm']['model'], 'prompt': prompt, 'stream': False}).encode(), headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=CFG['timeout_s']) as r:
                return 'ok', json.load(r).get('response', ''), round(time.monotonic() - started, 1)
        except Exception as exc:
            return 'error', type(exc).__name__, round(time.monotonic() - started, 1)
    home = ping.home_dir(provider)
    name = 'allmind-orch-' + provider
    argv = ['docker', 'run', '--rm', '--name', name, '--read-only', '--cap-drop', 'ALL',
            '--security-opt', 'no-new-privileges', '--memory', '1g', '--cpus', '1', '--pids-limit', '128',
            '--user', '1000:1000', '--log-driver', 'none',
            '--tmpfs', '/tmp:rw,nosuid,nodev,size=128m', '--tmpfs', '/job:rw,nosuid,nodev,uid=1000,gid=1000,mode=700,size=16m',
            '--mount', 'type=bind,src=' + str(home) + ',dst=/home/node',
            *ping.EXTRA.get(provider, ['-e', 'NO_BROWSER=true']), '--entrypoint', '/bin/sh', ping.IMAGE,
            '-c', 'umask 077; cd /job; exec "$@" </dev/null', 'orch', *cli_argv(provider, prompt, stage)]
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=CFG['timeout_s'])
        out, err = p.stdout or '', p.stderr or ''
        if p.returncode == 0 and out.strip():
            return 'ok', out.strip(), round(time.monotonic() - started, 1)
        both = out + '\n' + err
        for label, pattern in ping.PATTERNS:
            if re.search(pattern, both, re.I):
                return label, ping.mask(' '.join(err.split())[-300:]), round(time.monotonic() - started, 1)
        return 'error', ping.mask(' '.join(err.split())[-300:]), round(time.monotonic() - started, 1)
    except subprocess.TimeoutExpired:
        subprocess.run(['docker', 'stop', '--time', '1', name], capture_output=True, timeout=15)
        return 'timeout', None, round(time.monotonic() - started, 1)
    finally:
        ping.protect(home)


def process(tid, state, budget, cooldown, dry, progress):
    d = WORK / tid
    task = jload(d / 'task.json', None)
    if not task or task['status'] not in ('PENDING', 'WAITING_LIMIT', 'RUNNING'):
        return budget
    body = (d / 'task.md').read_text(encoding='utf-8')
    task['status'] = 'RUNNING'
    jsave(d / 'task.json', task)
    agent_event(state, {'type': 'task', 'task_id': tid, 'name': task['title'][:40], 'source': task_source(task)})
    while task['stage'] < len(task['stages']):
        stage = task['stages'][task['stage']]
        provider = stage['ai']
        if provider in cooldown:
            task['status'] = 'WAITING_LIMIT'
            event('WARNING', f'{task["title"]}: {provider} は使用枠のため次回へ持ち越し')
            break
        if budget <= 0:
            task['status'] = 'PENDING'
            event('INFO', f'{task["title"]}: 今回の呼び出し上限に達したため次回へ')
            break
        prev = ''
        if task['stage'] > 0:
            prev = (d / f"stage{task['stage'] - 1}.md").read_text(encoding='utf-8')
        agent_event(state, {'type': 'decision', 'task_id': tid, 'name': task['title'][:40], 'kind': 'RULE',
                            'question': f"{task['type']} {task['stage'] + 1}/{len(task['stages'])}: {stage['role']}",
                            'result': AGENT_ID[provider], 'dist': [{'id': AGENT_ID[provider], 'p': 1.0}], 'latency_ms': 0})
        progress(task, stage)
        status, output, dur = run_ai(provider, build_prompt(task, stage, body, prev), stage, dry)
        budget -= 1
        state['ai'][provider] = {'status': status, 'at': iso(), 'task': task['title']}
        task['history'].append({'stage': task['stage'], 'ai': provider, 'role': stage['role'], 'status': status, 'duration_s': dur, 'at': iso()})
        if status == 'ok':
            (d / f"stage{task['stage']}.md").write_text(output, encoding='utf-8')
            event('INFO', f'{task["title"]}: {provider}（{stage["role"]}）完了 {dur}s')
            agent_event(state, {'type': 'done', 'task_id': tid})
            task['stage'] += 1
        elif status == 'usage_limit':
            cooldown.add(provider)
            task['status'] = 'WAITING_LIMIT'
            event('WARNING', f'{task["title"]}: {provider} 使用枠到達（再試行せず次回へ）')
            break
        else:
            task['status'] = 'FAILED'
            (d / f"stage{task['stage']}.error").write_text(f'{status}: {output or ""}', encoding='utf-8')
            event('ERROR', f'{task["title"]}: {provider} {status}')
            break
    if task['status'] in ('FAILED', 'WAITING_LIMIT', 'PENDING') and task['stage'] < len(task['stages']):
        agent_event(state, {'type': 'judge', 'task_id': tid, 'name': task['title'][:40], 'kind': 'NOUL',
                            'question': f"{task['status']}（次回へ）", 'result': 'retry',
                            'dist': [{'id': 'retry', 'label': 'RETRY', 'p': 1.0}], 'latency_ms': 0})
    if task['stage'] >= len(task['stages']):
        last = (d / f"stage{len(task['stages']) - 1}.md").read_text(encoding='utf-8')
        verdict = 'SHIP' if 'VERDICT: SHIP' in last else ('RETRY' if 'VERDICT: RETRY' in last else None)
        report = [f"# {task['title']}", f"- 種別: {task['type']} / 作成: {task['created']} / 判定: {verdict or '—'}",
                  '- 状態: HUMAN APPROVAL（承認されるまで反映しない）', '']
        for i, s in enumerate(task['stages']):
            report += [f"## {i + 1}. {s['ai']}（{s['role']}）", (d / f'stage{i}.md').read_text(encoding='utf-8'), '']
        (OUTBOX / f'{tid}.md').write_text('\n'.join(report), encoding='utf-8')
        task.update(status='HUMAN APPROVAL', verdict=verdict)
        agent_event(state, {'type': 'judge', 'task_id': tid, 'name': task['title'][:40], 'kind': 'NOUL',
                            'question': f"判定 {verdict or '—'} → 承認待ち", 'result': 'human',
                            'dist': [{'id': 'human', 'label': 'HUMAN', 'p': 1.0}], 'latency_ms': 0})
        event('INFO', f'{task["title"]}: 承認待ちへ（判定 {verdict or "—"}）')
    task['updated'] = iso()
    jsave(d / 'task.json', task)
    return budget


# ------------------------------------------------------------------ ダッシュボード連携
JOB_DESC = {'trade': 'AI・BOT自動売買の検証（実注文なし）', 'freesoft': 'フリーソフト開発と販売', 'note': 'note等の情報販売記事',
            'vtuber': 'VTuber情報サイトの放置運営エンジン', 'aitech': 'AI技術・論文の収集と反映案'}


def digest_text(tid):
    for folder in (APPROVED, OUTBOX):
        f = folder / f'{tid}.md'
        if f.exists():
            return f.read_text(encoding='utf-8')
    return ''


def project_digests(state):
    """定期ジョブごとの進み具合と直近成果の要旨（Projects / Market / Tech 画面用。Private は含まない）。"""
    projects, digests = [], {}
    for job in CFG.get('jobs', []):
        tasks = [t for t in (jload(WORK / tid / 'task.json', None) for tid in state['tasks']) if t and t.get('job') == job['id']]
        approved = sum(1 for t in tasks if t['status'] == 'APPROVED')
        waiting = sum(1 for t in tasks if t['status'] == 'HUMAN APPROVAL')
        active = sum(1 for t in tasks if t['status'] in ('PENDING', 'RUNNING', 'WAITING_LIMIT'))
        last = max(tasks, key=lambda t: t['created']) if tasks else None
        text = digest_text(last['id']) if last else ''
        final = text.rsplit('\n## ', 1)[-1] if text else ''
        nxt = ''
        m = re.search(r'次回やること[^\n]*\n((?:.*\n?){1,4})', final)
        if m:
            nxt = ' '.join(l.strip('-・* ').strip() for l in m.group(1).splitlines() if l.strip())[:160]
        status = 'WAITING' if not last else {'HUMAN APPROVAL': 'REVIEW', 'APPROVED': 'COMPLETED', 'REJECTED': 'FAILED',
                                             'WAITING_LIMIT': 'PENDING'}.get(last['status'], last['status'])
        updated = datetime.datetime.fromisoformat(last['updated']).timestamp() if last else None
        projects.append({'name': job['title'], 'progress': round(100 * approved / len(tasks)) if tasks else 0, 'status': status,
                         'active': active + waiting, 'done': approved, 'total': len(tasks), 'updated_ts': updated,
                         'desc': (JOB_DESC.get(job['id'], '') + (' ／ 次回: ' + nxt if nxt else '')), 'job': job['id'],
                         'enabled': job.get('enabled', False)})
        digests[job['id']] = {'title': job['title'], 'status': last['status'] if last else None, 'verdict': last.get('verdict') if last else None,
                              'task_id': last['id'] if last else None, 'updated_ts': updated, 'next': nxt,
                              'excerpt': final[:1500]}
    return projects, digests


def publish(state, loop_index=None, loop_progress=0):
    tasks = []
    for tid in state['tasks'][-CFG['dashboard_tasks']:]:
        t = jload(WORK / tid / 'task.json', None)
        if not t:
            continue
        n = max(1, len(t['stages']))
        shown = {'APPROVED': 'COMPLETED', 'REJECTED': 'FAILED'}.get(t['status'], t['status'])
        tasks.append({'id': tid, 'name': t['title'], 'status': shown,
                      'progress': 100 if t['status'] in ('HUMAN APPROVAL', 'APPROVED') else round(100 * t['stage'] / n),
                      'eta': '—', 'time': datetime.datetime.fromisoformat(t['created']).astimezone().strftime('%H:%M')})
    tasks.reverse()
    done = sum(1 for t in tasks if t['status'] == 'HUMAN APPROVAL')
    events = []
    try:
        for line in (LOGS / 'orchestrator.jsonl').read_text(encoding='utf-8').splitlines()[-40:]:
            events.append(json.loads(line))
    except (OSError, ValueError):
        pass
    if loop_index is None:  # サイクル外の更新では直前の LOOP 表示を保つ
        loop = dict(jload(DASH, {}).get('loop') or {'current': 4, 'progress': 100})
    else:
        loop = {'current': loop_index, 'progress': loop_progress}
    loop.update(done=done, total=len(tasks), cycle=state['cycle'])
    projects, digests = project_digests(state)
    DASH.parent.mkdir(exist_ok=True)
    os.chmod(DASH.parent, 0o755)
    jsave(DASH, {'updated': time.time(), 'cycle': state['cycle'], 'last_cycle_end': state.get('last_cycle_end'),
                 'next_cycle_after': state.get('next_cycle_after'), 'tasks': tasks,
                 'loop': loop,
                 'ai': state['ai'], 'events': events, 'agent_events': state.get('agent_events', [])[-100:],
                 'projects': projects, 'digests': digests, 'drive': {k: v for k, v in (state.get('drive') or {}).items() if k != 'folder_id'},
                 'settings': {'interval_hours': CFG['interval_hours'], 'max_tasks_per_cycle': CFG['max_tasks_per_cycle'],
                              'max_calls_per_cycle': CFG['max_calls_per_cycle'], 'gemini_model': CFG['gemini_model'],
                              'pipelines': {k: ' → '.join(f"{s['ai']}({s['role']})" for s in v) for k, v in CFG['pipelines'].items()},
                              'jobs': [{'id': j['id'], 'title': j['title'], 'enabled': j.get('enabled'), 'every_cycles': j.get('every_cycles'),
                                        'offset': j.get('offset', 0), 'type': j['type']} for j in CFG.get('jobs', [])],
                              'cron': ['毎時7分: 5時間経過ならサイクル実行', '5分ごと: チャット投入・承認の取り込み', '起動時: 表示更新', '月曜4:30: 安全再起動（root）']}},
          mode=0o644)


def seed_ai_status(state):
    """直近の接続試験結果（ping.py）を AI 状態の初期値に使う。"""
    for f in Path(CFG['ping_results']).glob('*-ping.json'):
        r = jload(f, {})
        p = r.get('provider')
        if p and p not in state['ai']:
            state['ai'][p] = {'status': r.get('status'), 'at': r.get('observed_at'), 'task': None}


def write_report(state):
    """日次レポート（外出先で確認する用。Private は含めない＝タスク名・状態・判定・要旨のみ）。"""
    REPORTS.mkdir(mode=0o700, exist_ok=True)
    local = datetime.datetime.now().astimezone()
    rows, pending = [], []
    for tid in state['tasks'][-60:]:
        t = jload(WORK / tid / 'task.json', None)
        if not t or not t['created'][:10] >= (local - datetime.timedelta(days=1)).strftime('%Y-%m-%d'):
            continue
        created = datetime.datetime.fromisoformat(t['created']).astimezone()
        rows.append(f"| {created:%m-%d %H:%M} | {t['title']} | {t['type']} | {t['status']} | {t.get('verdict') or '—'} |")
        if t['status'] == 'HUMAN APPROVAL':
            pending.append(f"- `{tid}` {t['title']}（判定 {t.get('verdict') or '—'}）")
    ai = ', '.join(f"{k}: {v.get('status')}" for k, v in sorted(state['ai'].items()))
    text = '\n'.join([f"# ALL-MIND 日次レポート {local:%Y-%m-%d}", f"更新 {local:%H:%M} / サイクル #{state['cycle']}", '',
                      '## 承認待ち', *(pending or ['（なし）']), '', '## 直近24時間のタスク', '| 作成 | タスク | 種別 | 状態 | 判定 |', '|---|---|---|---|---|',
                      *(rows or ['| — | — | — | — | — |']), '', f"## AI 状態\n{ai or '—'}", ''])
    (REPORTS / f"{local:%Y-%m-%d}.md").write_text(text, encoding='utf-8')
    sync_drive(state)


def sync_drive(state):
    if not drive:
        return
    before = (state.get('drive') or {}).get('sync_status')
    info = drive.sync(state, REPORTS)
    if info.get('sync_status') == 'ok' and before != 'ok':
        event('INFO', 'Google Drive: 接続・レポート送信 OK', 'gdrive')
    elif info.get('sync_status') == 'error' and before != 'error':
        event('WARNING', f"Google Drive: 送信失敗（{info.get('error')}）", 'gdrive')
    if info.get('sync_status') != 'unconfigured':
        jsave(STATE, {**jload(STATE, {}), 'drive': state['drive']})


def decide(args, state):
    """承認操作: list / approve / reject / retry"""
    if args.cmd == 'list':
        for tid in state['tasks']:
            t = jload(WORK / tid / 'task.json', {})
            if t.get('status') == 'HUMAN APPROVAL':
                print(f"{tid}  {t['title']}  判定:{t.get('verdict') or '—'}  結果: {OUTBOX / (tid + '.md')}")
        return
    tid = args.task_id
    d = WORK / tid
    t = jload(d / 'task.json', None)
    if not t or tid not in state['tasks']:
        sys.exit('該当タスクがありません: ' + str(tid))
    if args.cmd == 'retry':
        t.update(status='PENDING', stage=0, updated=iso())
        event('INFO', f'{t["title"]}: やり直しを登録（次回サイクルで実行）', 'approval')
    else:
        if t['status'] != 'HUMAN APPROVAL':
            sys.exit('承認待ちではありません: ' + t['status'])
        dest = APPROVED if args.cmd == 'approve' else REJECTED
        dest.mkdir(mode=0o700, exist_ok=True)
        src = OUTBOX / f'{tid}.md'
        if src.exists():
            note = f"\n\n---\n{'承認' if args.cmd == 'approve' else '差し戻し'}: {iso()} {args.note or ''}\n"
            (dest / f'{tid}.md').write_text(src.read_text(encoding='utf-8') + note, encoding='utf-8')
            src.unlink()
        t.update(status='APPROVED' if args.cmd == 'approve' else 'REJECTED', decided=iso(), note=(args.note or '')[:200], updated=iso())
        event('INFO' if args.cmd == 'approve' else 'WARNING', f'{t["title"]}: {"承認" if args.cmd == "approve" else "差し戻し"}', 'approval')
    jsave(d / 'task.json', t)
    write_report(state)
    publish(state, 4, 100)
    print('OK', t['status'])


def tick(state):
    """5分ごと: チャットからの投入（*.md → inbox）と承認コマンド（*.cmd）を処理し、表示を更新。AI は呼ばない。"""
    if not CHAT.exists():
        return
    for f in sorted(CHAT.iterdir())[:50]:
        if f.is_symlink() or not f.is_file() or f.suffix not in ('.md', '.cmd') or f.stat().st_size > 20000:
            if f.suffix != '.part' or time.time() - f.stat().st_mtime > 600:
                f.unlink(missing_ok=True)
            continue
        if f.suffix == '.md':
            dest = INBOX / ('chat-' + f.stem + '.md')
            dest.write_text(f.read_text(encoding='utf-8', errors='replace'), encoding='utf-8')
            event('INFO', 'チャットからタスク投入を受付', 'chat')
        else:
            try:
                c = json.loads(f.read_text(encoding='utf-8'))
                ns = argparse.Namespace(cmd=c['cmd'], task_id=c['task_id'], note=c.get('note'))
                if ns.cmd in ('approve', 'reject', 'retry'):
                    try:
                        decide(ns, state)
                    except SystemExit as exc:
                        event('WARNING', f'チャット操作を実行できません: {exc}', 'chat')
            except (ValueError, KeyError):
                event('WARNING', 'チャット操作の形式が不正', 'chat')
        f.unlink(missing_ok=True)


def main():
    if len(sys.argv) > 1 and sys.argv[1] in ('list', 'approve', 'reject', 'retry'):
        dp = argparse.ArgumentParser()
        dp.add_argument('cmd')
        dp.add_argument('task_id', nargs='?')
        dp.add_argument('note', nargs='?')
        dargs = dp.parse_args()
        os.umask(0o077)
        decide(dargs, jload(STATE, {'cycle': 0, 'tasks': [], 'ai': {}}))
        return
    ap = argparse.ArgumentParser()
    ap.add_argument('--force', action='store_true', help='間隔ガードを無視して今すぐ1回実行')
    ap.add_argument('--dry-run', action='store_true', help='AI を呼ばずに流れだけ確認（試験環境用。本番の状態には使わない）')
    ap.add_argument('--status', action='store_true', help='サイクルを回さず、ダッシュボード用の状態ファイルだけ更新')
    ap.add_argument('--tick', action='store_true', help='チャット投入・承認コマンドの取り込み（5分ごと）')
    args = ap.parse_args()
    os.umask(0o077)
    for d in (INBOX, WORK, OUTBOX, LOGS):
        d.mkdir(parents=True, exist_ok=True)
    lock = open(LOGS / 'orchestrator.lock', 'w')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print('別の実行が進行中のため終了')
        return
    state = jload(STATE, {'cycle': 0, 'tasks': [], 'ai': {}, 'last_cycle_end': None})
    seed_ai_status(state)
    if args.status or args.tick:
        if args.tick:
            tick(state)
        if args.status:
            sync_drive(state)
        publish(state)
        return
    last = state.get('last_cycle_end')
    if last and not args.force and time.time() - last < CFG['interval_hours'] * 3600 - 300:
        return  # 前回の状態ファイルをそのまま残す
    state['cycle'] += 1
    event('INFO', f'サイクル #{state["cycle"]} 開始' + ('（dry-run）' if args.dry_run else ''))
    publish(state, 0, 10)
    schedule_jobs(state)
    ingest(state)
    publish(state, 1, 30)
    budget, cooldown = CFG['max_calls_per_cycle'], set()
    active = [tid for tid in state['tasks']
              if jload(WORK / tid / 'task.json', {}).get('status') in ('PENDING', 'WAITING_LIMIT', 'RUNNING')]
    for tid in active[:CFG['max_tasks_per_cycle']]:
        def progress(task, stage):
            state['ai'].setdefault(stage['ai'], {})['task'] = task['title']
            publish(state, 2, 50)
        budget = process(tid, state, budget, cooldown, args.dry_run, progress)
    for info in state['ai'].values():
        info['task'] = None  # 実行中の表示はサイクル終了で解除
    publish(state, 3, 80)
    state['last_cycle_end'] = time.time()
    state['next_cycle_after'] = state['last_cycle_end'] + CFG['interval_hours'] * 3600 - 300
    state['tasks'] = state['tasks'][-500:]
    jsave(STATE, state)
    event('INFO', f'サイクル #{state["cycle"]} 終了（残り呼び出し枠 {budget}）')
    write_report(state)
    publish(state, 4, 100)


if __name__ == '__main__':
    main()
